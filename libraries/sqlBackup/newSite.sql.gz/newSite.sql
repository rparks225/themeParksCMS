-- phpMyAdmin SQL Dump
-- version 4.4.14
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 09, 2016 at 04:58 PM
-- Server version: 5.6.26
-- PHP Version: 5.6.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `newSite`
--

-- --------------------------------------------------------

--
-- Table structure for table `careers`
--

CREATE TABLE IF NOT EXISTS `careers` (
  `Id` int(11) NOT NULL,
  `Job` varchar(255) NOT NULL,
  `Facility` varchar(255) NOT NULL,
  `Description` text NOT NULL,
  `Date` date NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `careers`
--

INSERT INTO `careers` (`Id`, `Job`, `Facility`, `Description`, `Date`) VALUES
(1, 'Test', 'Test', 'Test', '2015-11-23');

-- --------------------------------------------------------

--
-- Table structure for table `gallery`
--

CREATE TABLE IF NOT EXISTS `gallery` (
  `Id` int(11) NOT NULL,
  `Gallery` varchar(255) NOT NULL,
  `Cover` varchar(255) DEFAULT NULL,
  `Title` varchar(255) NOT NULL,
  `Order` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gallery`
--

INSERT INTO `gallery` (`Id`, `Gallery`, `Cover`, `Title`, `Order`) VALUES
(1, 'Posts', 'photo-4.jpg', 'Blog Post Images', 1);

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE IF NOT EXISTS `images` (
  `Id` int(11) NOT NULL,
  `Image` varchar(255) NOT NULL,
  `Title` varchar(255) NOT NULL,
  `Album` varchar(255) NOT NULL,
  `Order` int(11) DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=48 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `images`
--

INSERT INTO `images` (`Id`, `Image`, `Title`, `Album`, `Order`) VALUES
(31, 'photo-5.jpg', 'photo-5.jpg', 'Posts', 3),
(30, 'photo-4.jpg', 'photo-4.jpg', 'Posts', 1),
(28, 'photo-2.jpg', 'photo-2.jpg', 'Posts', 0),
(36, 'thumb.thumb.DSC_6647.jpg', 'thumb.thumb.DSC_6647.jpg', 'Posts', 2);

-- --------------------------------------------------------

--
-- Table structure for table `page`
--

CREATE TABLE IF NOT EXISTS `page` (
  `Id` int(11) NOT NULL,
  `Title` varchar(255) NOT NULL,
  `Editable` varchar(5) DEFAULT NULL,
  `Html` text,
  `Description` text NOT NULL,
  `KeyWords` text NOT NULL,
  `Heading` varchar(255) NOT NULL,
  `Nav` varchar(255) NOT NULL,
  `navId` int(11) DEFAULT NULL,
  `Navorder` varchar(255) DEFAULT NULL,
  `Location` varchar(255) NOT NULL,
  `Locationtext` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `page`
--

INSERT INTO `page` (`Id`, `Title`, `Editable`, `Html`, `Description`, `KeyWords`, `Heading`, `Nav`, `navId`, `Navorder`, `Location`, `Locationtext`) VALUES
(0, 'home', 'false', '', 'Home page', 'Home, page, home page', 'Welcome to {YOUR SITE}', 'yes', NULL, '0', 'Home', 'Home'),
(1, 'About', 'true', '', 'false', '', 'About Your SIte', 'parent', 1, '1', 'About', 'About'),
(2, 'post', 'false', '<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>Not editable</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n', 'Posts for all things posts!', 'Posts, Blog posts', 'Blog Post Edit', 'parent', 2, '2', 'News-All', 'Blog'),
(3, 'gallery', 'false', '', 'false', '', 'The Gallery page', 'yes', NULL, '3', 'Gallery', 'Gallery'),
(4, 'contact', 'false', '', '', 'Contact us, Contact, Us, Contact ', 'Contact Us', 'yes', NULL, '4', 'Contact', 'Contact'),
(10, 'pages', 'false', '<p>Not editable</p>\r\n', 'false', '', 'Add/Edit Page', '', NULL, '', '', ''),
(11, 'Dashboard', 'false', '<p>Not editable</p>', 'false', 'dashboard, edit ease, quick blog post', 'Dashboard', 'child', 2, '', 'tp-login', 'Dashboard'),
(23, '404', 'false', '<p>This is not the page you are looking for... move along</p>\r\n\r\n<p><a href="Home">&larr;Home</a></p>\r\n\r\n<p>&nbsp;</p>\r\n', 'false', '', '404 error page', '', NULL, '', '', ''),
(26, 'admin', 'false', '', 'false', '', 'Log into the Dasboard', '', NULL, '', '', ''),
(32, 'image', 'false', '', 'Here you can find the images from all of our events', 'Gallery , images, events,', 'Image Library', '', NULL, '', '', ''),
(39, 'employment', 'false', '', 'false', 'Job Opportunities, Jobs, Careers, Job Careeres', 'Employment Opportunities', 'child', 1, '', 'employment', 'Employment'),
(66, 'settings', 'false', '', 'false', '', 'Admin Settings', '', NULL, '', '', ''),
(68, 'Posts', 'false', '', '', '', 'News & Media', '', NULL, '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `post`
--

CREATE TABLE IF NOT EXISTS `post` (
  `Id` int(11) NOT NULL,
  `Title` varchar(250) NOT NULL,
  `Image` varchar(250) NOT NULL,
  `Description` text NOT NULL,
  `Updated` varchar(10) NOT NULL,
  `Date` varchar(100) NOT NULL,
  `Caption` varchar(535) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `post`
--

INSERT INTO `post` (`Id`, `Title`, `Image`, `Description`, `Updated`, `Date`, `Caption`) VALUES
(9, 'Open House Highlights Extensive Renovations at John Scott House', 'thumb.thumb.DSC_6647.jpg', '<p>John Scott House Rehabilitation &amp; Nursing Center in Braintree recently held an open house showcasing the&nbsp;extensive renovation to Welch Healthcare &amp; Retirement Group&rsquo;s first skilled nursing center. Over 100 healthcare&nbsp;professionals, legislative leaders and Welch Group staff marked the occasion by touring the renovated nursing&nbsp;center and enjoying a tasty menu including a traditional New England clam chowder, slider-style mini burgers and&nbsp;an assortment of delicious flatbreads.&nbsp;</p>\r\n\r\n<p>The extensive renovation,&nbsp;emphasizing resident comfort, safety and convenience,&nbsp;includes&nbsp;an expanded parking&nbsp;area with a new covered drive-up main entrance for the convenience of residents, family and friends; a refurbishment of all resident rooms and common areas. For patients and residents who require rehabilitation,&nbsp;John Scott House has relocated the rehabilitation gym to the newly designed post-acute short-term rehabilitation&nbsp;unit, and added a new dedicated living room and dining room. &nbsp;The renovation also features a remodeled front&nbsp;entrance and creation of new outdoor resident patio areas.&nbsp;</p>\r\n\r\n<p>&ldquo;For generations John Scott House has been an integral part of the Braintree community,&rdquo; says Kristen Reilly&nbsp;McHugh, administrator of John Scott House Rehabilitation &amp; Nursing Center. &ldquo;Our newly refurbished rehabilitation&nbsp;gym and living spaces demonstrate a continued commitment to enhancing the quality of life for our residents and&nbsp;short-term patients,&rdquo; added McHugh.&nbsp;</p>\r\n\r\n<p>Today, John Scott House Rehabilitation &amp; Nursing Center offers residents and their families the best of both worlds&nbsp;&ndash; a center rich in tradition and quality short-term rehabilitative and skilled nursing care. John Scott House offers&nbsp;the Braintree community high-level rehabilitative, medical, and nursing care on a short- or long-term basis. The&nbsp;Welch Group nursing center consistently receives high marks from state agencies that are designed to oversee the&nbsp;quality of nursing homes throughout Massachusetts.&nbsp;</p>\r\n\r\n<p>In addition, John Scott was recently awarded The Joint Commission&rsquo;s Gold Seal of Approval&trade; for Nursing Care&nbsp;Center Accreditation as well as the organization&rsquo;s new Post-Acute Care Certification, which demonstrates the&nbsp;facility&rsquo;s commitment to the highest level of care for its patients and residents&mdash;going beyond state and federal&nbsp;requirements.</p>\r\n\r\n<p>In 1949 the founders, the late Rita M. and Thomas (Frank) Welch, with four young children, made the decision to&nbsp;open their two-story Victorian home to care for frail older adults. This event marked the founding of the John&nbsp;Scott House.</p>\r\n\r\n<p>Welch Healthcare &amp; Retirement Group is a trusted family-owned senior services company. For over 65 years, the&nbsp;Welch Group has been a leading provider of rehabilitation, skilled nursing, assisted living memory care, assisted&nbsp;living and independent living options, adult day health and home care services in Massachusetts.</p>\r\n', '05/29/2016', '05/12/2016', 'John Scott House Administrator Kristen Reilly McHugh greets Braintree Mayor Joseph Sullivan, during an open house event held at the skilled nursing center.'),
(10, 'stuff', 'photo-5.jpg', '<p>Stuff goes here!!!</p>\r\n', ' 06/18/201', '12 June, 2', 'Add caption');

-- --------------------------------------------------------

--
-- Table structure for table `Products`
--

CREATE TABLE IF NOT EXISTS `Products` (
  `Id` int(11) NOT NULL,
  `Title` varchar(255) NOT NULL,
  `Description` text NOT NULL,
  `Grade` varchar(255) NOT NULL,
  `Image` varchar(255) NOT NULL,
  `Badges` varchar(255) NOT NULL,
  `Company` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Settings`
--

CREATE TABLE IF NOT EXISTS `Settings` (
  `Id` int(11) NOT NULL,
  `settings_siteName` varchar(255) NOT NULL,
  `settings_uName` varchar(255) NOT NULL,
  `settings_siteUrl` varchar(255) NOT NULL,
  `settings_captchaKey` text NOT NULL,
  `settings_cmsPath` varchar(255) NOT NULL,
  `settings_eePath` varchar(255) NOT NULL,
  `settings_emailHost` varchar(255) NOT NULL,
  `settings_emailAuth` varchar(255) NOT NULL,
  `settings_emailUser` varchar(255) NOT NULL,
  `settings_emailPass` varchar(255) NOT NULL,
  `settings_emailEncrypt` varchar(255) NOT NULL,
  `settings_emailPort` varchar(255) NOT NULL,
  `settings_emailFrom` varchar(255) NOT NULL,
  `settings_emailName` varchar(255) NOT NULL,
  `settings_emailAddress` varchar(255) NOT NULL,
  `settings_emailReply` varchar(255) NOT NULL,
  `settings_emailReplyTitle` varchar(255) NOT NULL,
  `theme` varchar(255) NOT NULL,
  `settings_dbName` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Settings`
--

INSERT INTO `Settings` (`Id`, `settings_siteName`, `settings_uName`, `settings_siteUrl`, `settings_captchaKey`, `settings_cmsPath`, `settings_eePath`, `settings_emailHost`, `settings_emailAuth`, `settings_emailUser`, `settings_emailPass`, `settings_emailEncrypt`, `settings_emailPort`, `settings_emailFrom`, `settings_emailName`, `settings_emailAddress`, `settings_emailReply`, `settings_emailReplyTitle`, `theme`, `settings_dbName`) VALUES
(1, 'New Site', 'Rob Parks', 'http://localhost/newSite/', '', '/newSite/', '/newSite/apps/_ee', 'smtp.gmail.com', 'true', 'rparks225@gmail.com', 'hpwlpyifujaflqal', 'tls', '587', 'no-reply@baneCare.com', 'BaneCare Website', 'sandrockc225@aol.com', 'info@baneCare.com', 'New Contact Form Message.', 'default', 'newSite');

-- --------------------------------------------------------

--
-- Table structure for table `Testimonials`
--

CREATE TABLE IF NOT EXISTS `Testimonials` (
  `Id` int(11) NOT NULL,
  `Name` varchar(255) NOT NULL,
  `Description` text NOT NULL,
  `Date` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Theme`
--

CREATE TABLE IF NOT EXISTS `Theme` (
  `Id` int(11) NOT NULL,
  `Theme` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Theme`
--

INSERT INTO `Theme` (`Id`, `Theme`) VALUES
(1, 'default');

-- --------------------------------------------------------

--
-- Table structure for table `U_sers`
--

CREATE TABLE IF NOT EXISTS `U_sers` (
  `Id` int(11) NOT NULL,
  `User_name` varchar(255) NOT NULL,
  `Pass_word` varchar(255) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Signed_Up` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `U_sers`
--

INSERT INTO `U_sers` (`Id`, `User_name`, `Pass_word`, `Email`, `Signed_Up`) VALUES
(1, 'rparks1', 'stuff', 'Fuck@off.com', '2015-06-17 18:51:16');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `careers`
--
ALTER TABLE `careers`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `gallery`
--
ALTER TABLE `gallery`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `page`
--
ALTER TABLE `page`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `post`
--
ALTER TABLE `post`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `Products`
--
ALTER TABLE `Products`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `Settings`
--
ALTER TABLE `Settings`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `Testimonials`
--
ALTER TABLE `Testimonials`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `Theme`
--
ALTER TABLE `Theme`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `U_sers`
--
ALTER TABLE `U_sers`
  ADD PRIMARY KEY (`Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `careers`
--
ALTER TABLE `careers`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `gallery`
--
ALTER TABLE `gallery`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `images`
--
ALTER TABLE `images`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=48;
--
-- AUTO_INCREMENT for table `page`
--
ALTER TABLE `page`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=69;
--
-- AUTO_INCREMENT for table `post`
--
ALTER TABLE `post`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `Products`
--
ALTER TABLE `Products`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Settings`
--
ALTER TABLE `Settings`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `Testimonials`
--
ALTER TABLE `Testimonials`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Theme`
--
ALTER TABLE `Theme`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `U_sers`
--
ALTER TABLE `U_sers`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
